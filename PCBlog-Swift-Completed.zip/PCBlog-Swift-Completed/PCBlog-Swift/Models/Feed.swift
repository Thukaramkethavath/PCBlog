//
//  Feed.swift
//  PCBlog-Swift
//
//  Created by Hoan Tran on 8/22/22.
//

import Foundation

// https://www.personalcapital.com/blog/feed/json

struct Feed: Codable {
    let title: String
    var items: [Item]
    
    var mostRecentItem: Item {
        return Item.recentItem
    }
    
    static private func readLocalFile(forName name: String) -> Data? {
        do {
            if let bundlePath = Bundle.main.path(forResource: name, ofType: "json"),
                let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                return jsonData
            }
        } catch {
            print(error)
        }
        
        return nil
    }
    
    static private func parse(jsonData: Data) -> Feed? {
        do {
            let decoder = JSONDecoder()
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ" 
            decoder.dateDecodingStrategy = .formatted(formatter)
                                                      
            let decodedData = try decoder.decode(Feed.self,
                                                       from: jsonData)
            return decodedData
        } catch {
            print("decode error")
            return nil
        }
    }
    
    static public func getFeed() -> Feed? {
        var res:Feed? = nil
        
        if let localData = self.readLocalFile(forName: "feed") {
            if let feed = self.parse(jsonData: localData) {
                res = feed
            }
        }
        return res
    }
    
}

