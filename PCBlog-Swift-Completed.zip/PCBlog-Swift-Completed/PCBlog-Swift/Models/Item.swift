//
//  Item.swift
//  PCBlog-Swift
//
//  Created by Hoan Tran on 8/22/22.
//

import Foundation

struct Item: Codable, Hashable {
    let id: String
    let url: String
    let category: String
    let categories: [String]
    let title: String
    let encoded_title: String
    let featured_image: String
    let summary: String
    let insight_summary: String
    let date_published: String
    let author: [String:String]
    let authors: [String]
    let tags: [String]
}

extension Item {
    static var recentItem =
    Item(id: "1234",
         url: "https://www.empower.com/the-currency/money/money-talks",
         category: "finance",
         categories: [],
         title: "Money Talks",
         encoded_title: "Money Talks",
         featured_image: "https://www.empower.com/sites/default/files/styles/small_hq/public/image/2023-04/money-talks_large.jpg?itok=4JTcJn0e",
         summary: "It’s time we had the money talk. Empower’s new research explores foundational perceptions about money, its biggest taboos, and Americans’ attitudes and behaviors around spending",
         insight_summary: "insight_summary",
         date_published: "2023-02-15T00:00:01+00:00",
         author: ["": ""],
         authors: [""],
         tags: [""])
}
