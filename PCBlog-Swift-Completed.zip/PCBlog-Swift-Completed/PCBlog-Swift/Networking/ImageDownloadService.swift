//
//  ImageDownloadService.swift
//  PCBlog-Swift
//
//  Created by Hoan Tran on 8/25/22.
//

import Foundation
import UIKit

class ImageDownloadService {
    private var cache = NSCache<NSString, UIImage>()

    func downloadFromURL(_ url: String) async throws -> UIImage {
        if let cachedImage = cache.object(forKey: url as NSString) {
            return cachedImage
        }
        
        let data = try await RestService.shared.getURL(url: url)
        guard let image = UIImage(data: data) else {
            throw NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "Could not create image from data"])
        }
        cache.setObject(image, forKey: url as NSString)
        return image
    }
}

