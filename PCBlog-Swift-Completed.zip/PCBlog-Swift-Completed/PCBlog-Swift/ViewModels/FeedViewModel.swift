//
//  FeedViewModel.swift
//  PCBlog-Swift
//
//  Created by Thukaram Kethavath on 6/11/23.
//

import Foundation
import UIKit

class FeedViewModel {
    
    var feed:Feed?
    
    // Dependancy for ImageDownloadService
    var imageDownloadService: ImageDownloadService!
    
    init(imageDownloadService: ImageDownloadService) {
        self.imageDownloadService = imageDownloadService
    }
    
    var mostRecentItem: Item? {
        return feed?.mostRecentItem
    }
    
    func fetchFeed() async throws {
        self.feed = Feed.getFeed()
    }
    
    // Asynchronously loads an image for a specific item.
    /// - Parameter item: The item to load the image for.
    /// - Throws: Propagates any errors thrown by `imageDownloadService.downloadFromURL()`.
    /// - Returns: The fetched `UIImage` object.
    func loadImageAsync(for item: Item) async throws -> UIImage? {
        
        do {
            let image = try await imageDownloadService.downloadFromURL(item.featured_image)
            return image
        } catch {
            // Rethrow any errors from the image download service
            throw error
        }
    }
    
}

