//
//  CollectionViewLayouts.swift
//  PCBlog-Swift
//
//  Created by Thukaram Kethavath on 6/11/23.
//

import Foundation
import UIKit

class CollectionViewLayouts {
    
    static let shared = CollectionViewLayouts()
    
    // Constants for layout configuration
    private let thirdOfView: CGFloat = 1.0 / 3.0
    private let fullView: CGFloat = 1.0
    private let sectionInsetTop: CGFloat = 10.0
    private let sectionInsetSides: CGFloat = 0.0
    private let sectionInsetBottom: CGFloat = 10.0
    private let itemInsets: CGFloat = 5.0
    private let interItemSpacing: CGFloat = 10.0
    private let interGroupSpacing: CGFloat = 20.0
    private let supplementaryHeaderSize: CGFloat = 30.0
    
    // Create a layout for the most recent item
    func mostRecentItemView(for view: UICollectionView)-> NSCollectionLayoutSection {
        // Define the item size
        let itemSize = NSCollectionLayoutSize(widthDimension: .absolute(view.bounds.width), heightDimension: .absolute(view.bounds.height * thirdOfView))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        
        // Create a group that contains the item
        let groupSize = NSCollectionLayoutSize(widthDimension: .absolute(view.bounds.width), heightDimension: .absolute(view.bounds.height * thirdOfView))
        let group = NSCollectionLayoutGroup.vertical(layoutSize: groupSize, subitem: item, count: 1)
        
        // Define the content insets for the group
        group.contentInsets = NSDirectionalEdgeInsets(top: sectionInsetTop, leading: sectionInsetSides, bottom: sectionInsetBottom, trailing: sectionInsetSides)
        
        // Create a section that contains the group
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = NSDirectionalEdgeInsets(top: sectionInsetTop, leading: sectionInsetSides, bottom: sectionInsetBottom, trailing: sectionInsetSides)
        return section
    }
    
    // Create a layout for the previously published articles
    func previouslyPublishedArticles(for view: UICollectionView) -> NSCollectionLayoutSection {
        // Define the item size
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(thirdOfView), heightDimension: .fractionalWidth(thirdOfView))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        
        // Define the content insets for the item
        item.contentInsets = NSDirectionalEdgeInsets(top: itemInsets, leading: itemInsets, bottom: itemInsets, trailing: itemInsets)
        
        // Create a horizontal group that contains the items
        let horizontalGroupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(fullView), heightDimension: .fractionalWidth(thirdOfView))
        let horizontalGroup = NSCollectionLayoutGroup.horizontal(layoutSize: horizontalGroupSize, subitem: item, count: 3)
        
        // Define the space between the items in the group
        horizontalGroup.interItemSpacing = .fixed(interItemSpacing)
        
        // Create a vertical group that contains the horizontal groups
        let verticalGroupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(fullView), heightDimension: .fractionalWidth(fullView))
        let verticalGroup = NSCollectionLayoutGroup.vertical(layoutSize: verticalGroupSize, subitem: horizontalGroup, count: 3)
        
        // Define the space between the groups
        verticalGroup.interItemSpacing = .fixed(interItemSpacing)
        
        // Create a section that contains the vertical group
        let section = NSCollectionLayoutSection(group: verticalGroup)
        
        // Define the space between the groups in the section
        section.interGroupSpacing = interGroupSpacing
        section.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: itemInsets * 3, bottom: sectionInsetBottom, trailing: itemInsets * 3)
        
        // Add a supplementary view (header) to the section
        let headerSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(fullView), heightDimension: .absolute(supplementaryHeaderSize))
        let header = NSCollectionLayoutBoundarySupplementaryItem(layoutSize: headerSize, elementKind: "Header", alignment: .top)
        section.boundarySupplementaryItems = [header]
        
        return section
    }
    
}
