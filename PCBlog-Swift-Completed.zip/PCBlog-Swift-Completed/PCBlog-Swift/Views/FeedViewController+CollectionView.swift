//
//  FeedViewController+CollectionView.swift
//  PCBlog-Swift
//
//  Created by Thukaram Kethavath on 6/11/23.
//

import Foundation
import UIKit

extension FeedViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    // MARK: - Collection View Layout
    func configureCompositionalLayout(){
        let layout = UICollectionViewCompositionalLayout {sectionIndex,enviroment in
            switch sectionIndex {
            case 0 :
                return CollectionViewLayouts.shared.mostRecentItemView(for: self.collectionView)
            default:
                return CollectionViewLayouts.shared.previouslyPublishedArticles(for: self.collectionView)
            }
        }
        collectionView.setCollectionViewLayout(layout, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch section {
        case 0 :
            return 1
        default:
            return viewModel?.feed?.items.count ?? 0
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch indexPath.section {
            
        case 0 :
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: FullWidthCollectionViewCell.identifier, for: indexPath) as? FullWidthCollectionViewCell else {fatalError("Unable deque cell...")}
            if let item = viewModel?.mostRecentItem {
                cell.configure(with: item)
                loadImage(for: item, in: cell)
            }
            return cell
            
        case 1 :
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PreviousArticleCell.identifier, for: indexPath) as? PreviousArticleCell else {fatalError("Unable deque cell...")}
            
            if let item = viewModel?.feed?.items[indexPath.row] {
                cell.configure(with: item)
                loadImage(for: item, in: cell)
            }
            
            return cell
            
        default:
            fatalError("Unable deque cell...")
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == "Header" {
            
            switch indexPath.section {
            case 1 :
                let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: PreviouslyPublishedHeaderView.reuseIdentifier, for: indexPath) as! PreviouslyPublishedHeaderView
                return header
            default :
                return UICollectionReusableView.init()
            }
            
        }else {
            return UICollectionReusableView.init()
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let feedItem = viewModel?.feed?.items[indexPath.row] else {
            return
        }
        
        let detailViewController = PopoverContentViewController()
        detailViewController.titleText = feedItem.title
        let navigationController = UINavigationController(rootViewController: detailViewController)
        navigationController.modalPresentationStyle = .formSheet
        
        // Set the color of the separator line
        navigationController.navigationBar.standardAppearance = getAppearanceForNavigationBar()
        navigationController.navigationBar.compactAppearance = getAppearanceForNavigationBar()
        navigationController.navigationBar.scrollEdgeAppearance = getAppearanceForNavigationBar()
        
        self.present(navigationController, animated: true, completion: nil)
    }
    
    func getAppearanceForNavigationBar() -> UINavigationBarAppearance {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = .white
        appearance.shadowImage = UIImage() // Hide the default shadow image
        appearance.shadowColor = .gray
        return appearance
    }
}

