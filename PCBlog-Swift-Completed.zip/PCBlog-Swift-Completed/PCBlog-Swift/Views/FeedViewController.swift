//
//  FeedViewController.swift
//  PCBlog-Swift
//
//  Created by Hoan Tran on 8/22/22.
//

import UIKit

class FeedViewController: UIViewController {
    
    var viewModel: FeedViewModel?
    private var loadingTasks = [Item: Task<(), Never>]()
    
    lazy var collectionView : UICollectionView = {
        let cv = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewFlowLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsVerticalScrollIndicator = false
        cv.delegate = self
        cv.dataSource = self
        
        cv.register(FullWidthCollectionViewCell.self, forCellWithReuseIdentifier: FullWidthCollectionViewCell.identifier)
        cv.register(PreviousArticleCell.self, forCellWithReuseIdentifier: PreviousArticleCell.identifier)
        cv.register(PreviouslyPublishedHeaderView.self, forSupplementaryViewOfKind: "Header", withReuseIdentifier: PreviouslyPublishedHeaderView.reuseIdentifier)
        
        cv.backgroundColor = .systemBackground
        return cv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureNavigationController()
        viewModel = FeedViewModel(imageDownloadService: ImageDownloadService())
        view.addSubview(collectionView)
        collectionView.setUp(to: view)
        configureCompositionalLayout()
        fetchData()
    }
    
    private func configureNavigationController() {
        title = "The currency \u{2122}"
        navigationController?.view.backgroundColor = .white
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.barTintColor = .white
        navigationController?.navigationBar.tintColor = .white
    }
    
    private func fetchData() {
        Task { [weak self] in
            guard let self = self else { return }
            do {
                try await self.viewModel?.fetchFeed()
                DispatchQueue.main.async { [weak self] in
                    self?.collectionView.reloadData()
                }
            } catch {
                showErrorAlert(withMessage: error.localizedDescription)
            }
        }
    }
    
    func loadImage(for item: Item, in cell: ImageLoadingProtocol) {
        loadingTasks[item]?.cancel()
        
        let task = Task { [weak self] in
            guard let self = self else { return }
            do {
                if let image = try await self.viewModel?.loadImageAsync(for: item) {
                    DispatchQueue.main.async {
                        cell.imageView.image = image
                    }
                }
            } catch {
                showErrorAlert(withMessage: error.localizedDescription)
            }
        }
        
        loadingTasks[item] = task
    }
    
    func showErrorAlert(withMessage message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        DispatchQueue.main.async { [weak self] in
            self?.present(alert, animated: true, completion: nil)
        }
    }
}


